using System;
using System.Data;
using System.Data.SqlClient;
using HotelManagementSystem.Models;

namespace HotelManagementSystem.DAL
{
    /// <summary>
    /// Data Access Layer for Customer operations
    /// </summary>
    public class CustomerDAL
    {
        /// <summary>
        /// Gets total number of customers
        /// </summary>
        public static int GetCustomerCount()
        {
            string query = "SELECT COUNT(*) FROM Customers";
            object result = DatabaseHelper.ExecuteScalar(query);
            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Gets all customers from the database
        /// </summary>
        public static DataTable GetAllCustomers()
        {
            string query = "SELECT CustomerID, FirstName, LastName, Phone, Email, IDNumber FROM Customers ORDER BY LastName, FirstName";
            return DatabaseHelper.ExecuteQuery(query);
        }

        /// <summary>
        /// Gets a customer by ID
        /// </summary>
        public static Customer GetCustomerById(int customerId)
        {
            string query = "SELECT CustomerID, FirstName, LastName, Phone, Email, IDNumber FROM Customers WHERE CustomerID = @CustomerID";
            SqlParameter[] parameters = {
                new SqlParameter("@CustomerID", customerId)
            };

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query, parameters);
            if (dataTable.Rows.Count > 0)
            {
                DataRow row = dataTable.Rows[0];
                return new Customer
                {
                    CustomerID = Convert.ToInt32(row["CustomerID"]),
                    FirstName = row["FirstName"].ToString(),
                    LastName = row["LastName"].ToString(),
                    Phone = row["Phone"].ToString(),
                    Email = row["Email"].ToString(),
                    IDNumber = row["IDNumber"].ToString()
                };
            }
            return null;
        }

        /// <summary>
        /// Searches customers by name or phone
        /// </summary>
        public static DataTable SearchCustomers(string searchTerm)
        {
            string query = @"SELECT CustomerID, FirstName, LastName, Phone, Email, IDNumber 
                           FROM Customers 
                           WHERE FirstName LIKE @SearchTerm OR LastName LIKE @SearchTerm OR Phone LIKE @SearchTerm
                           ORDER BY LastName, FirstName";
            SqlParameter[] parameters = {
                new SqlParameter("@SearchTerm", $"%{searchTerm}%")
            };

            return DatabaseHelper.ExecuteQuery(query, parameters);
        }

        /// <summary>
        /// Adds a new customer
        /// </summary>
        public static bool AddCustomer(Customer customer)
        {
            string query = "INSERT INTO Customers (FirstName, LastName, Phone, Email, IDNumber) VALUES (@FirstName, @LastName, @Phone, @Email, @IDNumber)";
            SqlParameter[] parameters = {
                new SqlParameter("@FirstName", customer.FirstName),
                new SqlParameter("@LastName", customer.LastName),
                new SqlParameter("@Phone", customer.Phone),
                new SqlParameter("@Email", string.IsNullOrEmpty(customer.Email) ? DBNull.Value : (object)customer.Email),
                new SqlParameter("@IDNumber", string.IsNullOrEmpty(customer.IDNumber) ? DBNull.Value : (object)customer.IDNumber)
            };

            return DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        /// <summary>
        /// Updates an existing customer
        /// </summary>
        public static bool UpdateCustomer(Customer customer)
        {
            string query = "UPDATE Customers SET FirstName = @FirstName, LastName = @LastName, Phone = @Phone, Email = @Email, IDNumber = @IDNumber WHERE CustomerID = @CustomerID";
            SqlParameter[] parameters = {
                new SqlParameter("@CustomerID", customer.CustomerID),
                new SqlParameter("@FirstName", customer.FirstName),
                new SqlParameter("@LastName", customer.LastName),
                new SqlParameter("@Phone", customer.Phone),
                new SqlParameter("@Email", string.IsNullOrEmpty(customer.Email) ? DBNull.Value : (object)customer.Email),
                new SqlParameter("@IDNumber", string.IsNullOrEmpty(customer.IDNumber) ? DBNull.Value : (object)customer.IDNumber)
            };

            return DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        /// <summary>
        /// Deletes a customer
        /// </summary>
        public static bool DeleteCustomer(int customerId)
        {
            // Check if customer has reservations
            string checkQuery = "SELECT COUNT(*) FROM Reservations WHERE CustomerID = @CustomerID";
            SqlParameter[] checkParams = {
                new SqlParameter("@CustomerID", customerId)
            };

            int reservationCount = Convert.ToInt32(DatabaseHelper.ExecuteScalar(checkQuery, checkParams));
            if (reservationCount > 0)
            {
                throw new Exception("Cannot delete customer with existing reservations. Delete reservations first.");
            }

            string query = "DELETE FROM Customers WHERE CustomerID = @CustomerID";
            SqlParameter[] parameters = {
                new SqlParameter("@CustomerID", customerId)
            };

            return DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;
        }
    }
}
