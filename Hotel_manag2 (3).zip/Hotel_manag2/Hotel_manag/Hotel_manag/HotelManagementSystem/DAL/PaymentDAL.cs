using System;
using System.Data;
using System.Data.SqlClient;
using HotelManagementSystem.Models;

namespace HotelManagementSystem.DAL
{
    /// <summary>
    /// Data Access Layer for Payment operations
    /// </summary>
    public class PaymentDAL
    {
        /// <summary>
        /// Gets all payments with reservation information
        /// </summary>
        public static DataTable GetAllPayments()
        {
            string query = @"SELECT p.PaymentID, p.ReservationID, p.PaymentDate, p.Amount, p.PaymentMethod,
                           c.FirstName + ' ' + c.LastName AS CustomerName,
                           rm.RoomNumber
                           FROM Payments p
                           INNER JOIN Reservations r ON p.ReservationID = r.ReservationID
                           INNER JOIN Customers c ON r.CustomerID = c.CustomerID
                           INNER JOIN Rooms rm ON r.RoomID = rm.RoomID
                           ORDER BY p.PaymentDate DESC";
            return DatabaseHelper.ExecuteQuery(query);
        }

        /// <summary>
        /// Gets payments for a specific reservation
        /// </summary>
        public static DataTable GetPaymentsByReservation(int reservationId)
        {
            string query = @"SELECT p.PaymentID, p.ReservationID, p.PaymentDate, p.Amount, p.PaymentMethod,
                           c.FirstName + ' ' + c.LastName AS CustomerName,
                           rm.RoomNumber
                           FROM Payments p
                           INNER JOIN Reservations r ON p.ReservationID = r.ReservationID
                           INNER JOIN Customers c ON r.CustomerID = c.CustomerID
                           INNER JOIN Rooms rm ON r.RoomID = rm.RoomID
                           WHERE p.ReservationID = @ReservationID
                           ORDER BY p.PaymentDate DESC";
            SqlParameter[] parameters = {
                new SqlParameter("@ReservationID", reservationId)
            };

            return DatabaseHelper.ExecuteQuery(query, parameters);
        }

        /// <summary>
        /// Gets total amount paid for a reservation
        /// </summary>
        public static decimal GetTotalPaidForReservation(int reservationId)
        {
            string query = "SELECT ISNULL(SUM(Amount), 0) FROM Payments WHERE ReservationID = @ReservationID";
            SqlParameter[] parameters = {
                new SqlParameter("@ReservationID", reservationId)
            };

            object result = DatabaseHelper.ExecuteScalar(query, parameters);
            return result != null && result != DBNull.Value ? Convert.ToDecimal(result) : 0;
        }

        /// <summary>
        /// Gets a payment by ID
        /// </summary>
        public static Payment GetPaymentById(int paymentId)
        {
            string query = @"SELECT p.PaymentID, p.ReservationID, p.PaymentDate, p.Amount, p.PaymentMethod,
                           c.FirstName + ' ' + c.LastName AS CustomerName,
                           rm.RoomNumber
                           FROM Payments p
                           INNER JOIN Reservations r ON p.ReservationID = r.ReservationID
                           INNER JOIN Customers c ON r.CustomerID = c.CustomerID
                           INNER JOIN Rooms rm ON r.RoomID = rm.RoomID
                           WHERE p.PaymentID = @PaymentID";
            SqlParameter[] parameters = {
                new SqlParameter("@PaymentID", paymentId)
            };

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query, parameters);
            if (dataTable.Rows.Count > 0)
            {
                DataRow row = dataTable.Rows[0];
                return new Payment
                {
                    PaymentID = Convert.ToInt32(row["PaymentID"]),
                    ReservationID = Convert.ToInt32(row["ReservationID"]),
                    PaymentDate = Convert.ToDateTime(row["PaymentDate"]),
                    Amount = Convert.ToDecimal(row["Amount"]),
                    PaymentMethod = row["PaymentMethod"].ToString(),
                    CustomerName = row["CustomerName"].ToString(),
                    RoomNumber = row["RoomNumber"].ToString()
                };
            }
            return null;
        }

        /// <summary>
        /// Adds a new payment
        /// </summary>
        public static bool AddPayment(Payment payment)
        {
            // Verify reservation exists
            Reservation reservation = ReservationDAL.GetReservationById(payment.ReservationID);
            if (reservation == null)
            {
                throw new Exception("Reservation not found.");
            }

            string query = "INSERT INTO Payments (ReservationID, PaymentDate, Amount, PaymentMethod) VALUES (@ReservationID, @PaymentDate, @Amount, @PaymentMethod)";
            SqlParameter[] parameters = {
                new SqlParameter("@ReservationID", payment.ReservationID),
                new SqlParameter("@PaymentDate", payment.PaymentDate),
                new SqlParameter("@Amount", payment.Amount),
                new SqlParameter("@PaymentMethod", payment.PaymentMethod)
            };

            return DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        /// <summary>
        /// Updates an existing payment
        /// </summary>
        public static bool UpdatePayment(Payment payment)
        {
            string query = "UPDATE Payments SET ReservationID = @ReservationID, PaymentDate = @PaymentDate, Amount = @Amount, PaymentMethod = @PaymentMethod WHERE PaymentID = @PaymentID";
            SqlParameter[] parameters = {
                new SqlParameter("@PaymentID", payment.PaymentID),
                new SqlParameter("@ReservationID", payment.ReservationID),
                new SqlParameter("@PaymentDate", payment.PaymentDate),
                new SqlParameter("@Amount", payment.Amount),
                new SqlParameter("@PaymentMethod", payment.PaymentMethod)
            };

            return DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        /// <summary>
        /// Deletes a payment
        /// </summary>
        public static bool DeletePayment(int paymentId)
        {
            string query = "DELETE FROM Payments WHERE PaymentID = @PaymentID";
            SqlParameter[] parameters = {
                new SqlParameter("@PaymentID", paymentId)
            };

            return DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;
        }
    }
}
