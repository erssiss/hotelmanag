using System;
using System.Data;
using System.Data.SqlClient;
using HotelManagementSystem.Models;

namespace HotelManagementSystem.DAL
{
    /// <summary>
    /// Data Access Layer for Reservation operations
    /// </summary>
    public class ReservationDAL
    {
        /// <summary>
        /// Gets count of active reservations (Booked or CheckedIn)
        /// </summary>
        public static int GetActiveReservationCount()
        {
            string query = "SELECT COUNT(*) FROM Reservations WHERE Status IN ('Booked', 'CheckedIn')";
            object result = DatabaseHelper.ExecuteScalar(query);
            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Gets all reservations with customer and room information
        /// </summary>
        public static DataTable GetAllReservations()
        {
            string query = @"SELECT r.ReservationID, r.CustomerID, r.RoomID, r.CheckInDate, r.CheckOutDate, 
                           r.TotalPrice, r.Status, r.ActualCheckIn, r.ActualCheckOut,
                           c.FirstName + ' ' + c.LastName AS CustomerName,
                           rm.RoomNumber
                           FROM Reservations r
                           INNER JOIN Customers c ON r.CustomerID = c.CustomerID
                           INNER JOIN Rooms rm ON r.RoomID = rm.RoomID
                           ORDER BY r.CheckInDate DESC";
            return DatabaseHelper.ExecuteQuery(query);
        }

        /// <summary>
        /// Gets a reservation by ID
        /// </summary>
        public static Reservation GetReservationById(int reservationId)
        {
            string query = @"SELECT r.ReservationID, r.CustomerID, r.RoomID, r.CheckInDate, r.CheckOutDate, 
                           r.TotalPrice, r.Status, r.ActualCheckIn, r.ActualCheckOut,
                           c.FirstName + ' ' + c.LastName AS CustomerName,
                           rm.RoomNumber
                           FROM Reservations r
                           INNER JOIN Customers c ON r.CustomerID = c.CustomerID
                           INNER JOIN Rooms rm ON r.RoomID = rm.RoomID
                           WHERE r.ReservationID = @ReservationID";
            SqlParameter[] parameters = {
                new SqlParameter("@ReservationID", reservationId)
            };

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query, parameters);
            if (dataTable.Rows.Count > 0)
            {
                DataRow row = dataTable.Rows[0];
                return new Reservation
                {
                    ReservationID = Convert.ToInt32(row["ReservationID"]),
                    CustomerID = Convert.ToInt32(row["CustomerID"]),
                    RoomID = Convert.ToInt32(row["RoomID"]),
                    CheckInDate = Convert.ToDateTime(row["CheckInDate"]),
                    CheckOutDate = Convert.ToDateTime(row["CheckOutDate"]),
                    TotalPrice = Convert.ToDecimal(row["TotalPrice"]),
                    Status = row["Status"].ToString(),
                    ActualCheckIn = row["ActualCheckIn"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["ActualCheckIn"]),
                    ActualCheckOut = row["ActualCheckOut"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["ActualCheckOut"]),
                    CustomerName = row["CustomerName"].ToString(),
                    RoomNumber = row["RoomNumber"].ToString()
                };
            }
            return null;
        }

        /// <summary>
        /// Gets reservations for a specific customer
        /// </summary>
        public static DataTable GetReservationsByCustomer(int customerId)
        {
            string query = @"SELECT r.ReservationID, r.CustomerID, r.RoomID, r.CheckInDate, r.CheckOutDate, 
                           r.TotalPrice, r.Status,
                           c.FirstName + ' ' + c.LastName AS CustomerName,
                           rm.RoomNumber
                           FROM Reservations r
                           INNER JOIN Customers c ON r.CustomerID = c.CustomerID
                           INNER JOIN Rooms rm ON r.RoomID = rm.RoomID
                           WHERE r.CustomerID = @CustomerID
                           ORDER BY r.CheckInDate DESC";
            SqlParameter[] parameters = {
                new SqlParameter("@CustomerID", customerId)
            };

            return DatabaseHelper.ExecuteQuery(query, parameters);
        }

        /// <summary>
        /// Checks if a room is available for the given date range
        /// </summary>
        public static bool IsRoomAvailable(int roomId, DateTime checkIn, DateTime checkOut, int excludeReservationId = 0)
        {
            string query = @"SELECT COUNT(*) FROM Reservations 
                           WHERE RoomID = @RoomID 
                           AND Status IN ('Booked', 'CheckedIn')
                           AND ReservationID != @ExcludeReservationID
                           AND ((CheckInDate <= @CheckInDate AND CheckOutDate > @CheckInDate)
                           OR (CheckInDate < @CheckOutDate AND CheckOutDate >= @CheckOutDate)
                           OR (CheckInDate >= @CheckInDate AND CheckOutDate <= @CheckOutDate))";
            SqlParameter[] parameters = {
                new SqlParameter("@RoomID", roomId),
                new SqlParameter("@CheckInDate", checkIn.Date),
                new SqlParameter("@CheckOutDate", checkOut.Date),
                new SqlParameter("@ExcludeReservationID", excludeReservationId)
            };

            int count = Convert.ToInt32(DatabaseHelper.ExecuteScalar(query, parameters));
            return count == 0;
        }

        /// <summary>
        /// Adds a new reservation
        /// </summary>
        public static bool AddReservation(Reservation reservation)
        {
            // Check if room is available
            if (!IsRoomAvailable(reservation.RoomID, reservation.CheckInDate, reservation.CheckOutDate))
            {
                throw new Exception("Room is not available for the selected dates.");
            }

            string query = @"INSERT INTO Reservations (CustomerID, RoomID, CheckInDate, CheckOutDate, TotalPrice, Status) 
                           VALUES (@CustomerID, @RoomID, @CheckInDate, @CheckOutDate, @TotalPrice, @Status)";
            SqlParameter[] parameters = {
                new SqlParameter("@CustomerID", reservation.CustomerID),
                new SqlParameter("@RoomID", reservation.RoomID),
                new SqlParameter("@CheckInDate", reservation.CheckInDate.Date),
                new SqlParameter("@CheckOutDate", reservation.CheckOutDate.Date),
                new SqlParameter("@TotalPrice", reservation.TotalPrice),
                new SqlParameter("@Status", reservation.Status)
            };

            bool result = DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;

            // Update room availability if status is Booked or CheckedIn
            if (result && (reservation.Status == "Booked" || reservation.Status == "CheckedIn"))
            {
                RoomDAL.UpdateRoomAvailability(reservation.RoomID, false);
            }

            return result;
        }

        /// <summary>
        /// Updates an existing reservation
        /// </summary>
        public static bool UpdateReservation(Reservation reservation)
        {
            // Get old reservation to check room changes
            Reservation oldReservation = GetReservationById(reservation.ReservationID);
            if (oldReservation == null)
            {
                throw new Exception("Reservation not found.");
            }

            // Check if room is available (if room or dates changed)
            if (reservation.RoomID != oldReservation.RoomID || 
                reservation.CheckInDate != oldReservation.CheckInDate || 
                reservation.CheckOutDate != oldReservation.CheckOutDate)
            {
                if (!IsRoomAvailable(reservation.RoomID, reservation.CheckInDate, reservation.CheckOutDate, reservation.ReservationID))
                {
                    throw new Exception("Room is not available for the selected dates.");
                }
            }

            string query = @"UPDATE Reservations 
                           SET CustomerID = @CustomerID, RoomID = @RoomID, CheckInDate = @CheckInDate, 
                           CheckOutDate = @CheckOutDate, TotalPrice = @TotalPrice, Status = @Status 
                           WHERE ReservationID = @ReservationID";
            SqlParameter[] parameters = {
                new SqlParameter("@ReservationID", reservation.ReservationID),
                new SqlParameter("@CustomerID", reservation.CustomerID),
                new SqlParameter("@RoomID", reservation.RoomID),
                new SqlParameter("@CheckInDate", reservation.CheckInDate.Date),
                new SqlParameter("@CheckOutDate", reservation.CheckOutDate.Date),
                new SqlParameter("@TotalPrice", reservation.TotalPrice),
                new SqlParameter("@Status", reservation.Status)
            };

            bool result = DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;

            // Update room availability
            if (result)
            {
                // Free old room if it changed
                if (oldReservation.RoomID != reservation.RoomID)
                {
                    RoomDAL.UpdateRoomAvailability(oldReservation.RoomID, true);
                }

                // Update new room availability
                if (reservation.Status == "Booked" || reservation.Status == "CheckedIn")
                {
                    RoomDAL.UpdateRoomAvailability(reservation.RoomID, false);
                }
                else if (reservation.Status == "CheckedOut" || reservation.Status == "Cancelled")
                {
                    RoomDAL.UpdateRoomAvailability(reservation.RoomID, true);
                }
            }

            return result;
        }

        /// <summary>
        /// Deletes a reservation
        /// </summary>
        public static bool DeleteReservation(int reservationId)
        {
            Reservation reservation = GetReservationById(reservationId);
            if (reservation == null)
            {
                return false;
            }

            string query = "DELETE FROM Reservations WHERE ReservationID = @ReservationID";
            SqlParameter[] parameters = {
                new SqlParameter("@ReservationID", reservationId)
            };

            bool result = DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;

            // Free the room
            if (result)
            {
                RoomDAL.UpdateRoomAvailability(reservation.RoomID, true);
            }

            return result;
        }

        /// <summary>
        /// Calculates total price based on room price and number of nights
        /// </summary>
        public static decimal CalculateTotalPrice(int roomId, DateTime checkIn, DateTime checkOut)
        {
            Room room = RoomDAL.GetRoomById(roomId);
            if (room == null)
            {
                return 0;
            }

            int nights = (checkOut.Date - checkIn.Date).Days;
            return room.PricePerNight * nights;
        }

        /// <summary>
        /// Performs check-in for a reservation: sets status, actual check-in time and marks room unavailable.
        /// </summary>
        public static bool CheckInReservation(int reservationId)
        {
            Reservation reservation = GetReservationById(reservationId);
            if (reservation == null)
            {
                throw new Exception("Reservation not found.");
            }

            if (!string.Equals(reservation.Status, "Booked", StringComparison.OrdinalIgnoreCase))
            {
                throw new Exception("Only reservations with status 'Booked' can be checked in.");
            }

            string query = @"UPDATE Reservations 
                             SET Status = @Status, ActualCheckIn = @ActualCheckIn 
                             WHERE ReservationID = @ReservationID AND Status = 'Booked'";
            SqlParameter[] parameters = {
                new SqlParameter("@Status", "CheckedIn"),
                new SqlParameter("@ActualCheckIn", DateTime.Now),
                new SqlParameter("@ReservationID", reservationId)
            };

            bool result = DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;

            if (result)
            {
                // Mark room as unavailable
                RoomDAL.UpdateRoomAvailability(reservation.RoomID, false);
            }

            return result;
        }

        /// <summary>
        /// Performs check-out for a reservation: sets status, actual check-out time and marks room available.
        /// </summary>
        public static bool CheckOutReservation(int reservationId)
        {
            Reservation reservation = GetReservationById(reservationId);
            if (reservation == null)
            {
                throw new Exception("Reservation not found.");
            }

            if (!string.Equals(reservation.Status, "CheckedIn", StringComparison.OrdinalIgnoreCase))
            {
                throw new Exception("Only reservations with status 'CheckedIn' can be checked out.");
            }

            string query = @"UPDATE Reservations 
                             SET Status = @Status, ActualCheckOut = @ActualCheckOut 
                             WHERE ReservationID = @ReservationID AND Status = 'CheckedIn'";
            SqlParameter[] parameters = {
                new SqlParameter("@Status", "CheckedOut"),
                new SqlParameter("@ActualCheckOut", DateTime.Now),
                new SqlParameter("@ReservationID", reservationId)
            };

            bool result = DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;

            if (result)
            {
                // Mark room as available again
                RoomDAL.UpdateRoomAvailability(reservation.RoomID, true);
            }

            return result;
        }
    }
}
