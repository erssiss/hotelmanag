using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using HotelManagementSystem.Models;

namespace HotelManagementSystem.DAL
{
    /// <summary>
    /// Data Access Layer for Room operations
    /// </summary>
    public class RoomDAL
    {
        /// <summary>
        /// Gets total number of rooms
        /// </summary>
        public static int GetRoomCount()
        {
            string query = "SELECT COUNT(*) FROM Rooms";
            object result = DatabaseHelper.ExecuteScalar(query);
            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Gets number of available rooms
        /// </summary>
        public static int GetAvailableRoomCount()
        {
            string query = "SELECT COUNT(*) FROM Rooms WHERE IsAvailable = 1";
            object result = DatabaseHelper.ExecuteScalar(query);
            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Gets all rooms from the database
        /// </summary>
        public static DataTable GetAllRooms()
        {
            string query = "SELECT RoomID, RoomNumber, RoomType, PricePerNight, IsAvailable FROM Rooms ORDER BY RoomNumber";
            return DatabaseHelper.ExecuteQuery(query);
        }

        /// <summary>
        /// Gets all available rooms
        /// </summary>
        public static DataTable GetAvailableRooms()
        {
            string query = "SELECT RoomID, RoomNumber, RoomType, PricePerNight FROM Rooms WHERE IsAvailable = 1 ORDER BY RoomNumber";
            return DatabaseHelper.ExecuteQuery(query);
        }

        /// <summary>
        /// Gets a room by ID
        /// </summary>
        public static Room GetRoomById(int roomId)
        {
            string query = "SELECT RoomID, RoomNumber, RoomType, PricePerNight, IsAvailable FROM Rooms WHERE RoomID = @RoomID";
            SqlParameter[] parameters = {
                new SqlParameter("@RoomID", roomId)
            };

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query, parameters);
            if (dataTable.Rows.Count > 0)
            {
                DataRow row = dataTable.Rows[0];
                return new Room
                {
                    RoomID = Convert.ToInt32(row["RoomID"]),
                    RoomNumber = row["RoomNumber"].ToString(),
                    RoomType = row["RoomType"].ToString(),
                    PricePerNight = Convert.ToDecimal(row["PricePerNight"]),
                    IsAvailable = Convert.ToBoolean(row["IsAvailable"])
                };
            }
            return null;
        }

        /// <summary>
        /// Gets a room by room number
        /// </summary>
        public static Room GetRoomByNumber(string roomNumber)
        {
            string query = "SELECT RoomID, RoomNumber, RoomType, PricePerNight, IsAvailable FROM Rooms WHERE RoomNumber = @RoomNumber";
            SqlParameter[] parameters = {
                new SqlParameter("@RoomNumber", roomNumber)
            };

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query, parameters);
            if (dataTable.Rows.Count > 0)
            {
                DataRow row = dataTable.Rows[0];
                return new Room
                {
                    RoomID = Convert.ToInt32(row["RoomID"]),
                    RoomNumber = row["RoomNumber"].ToString(),
                    RoomType = row["RoomType"].ToString(),
                    PricePerNight = Convert.ToDecimal(row["PricePerNight"]),
                    IsAvailable = Convert.ToBoolean(row["IsAvailable"])
                };
            }
            return null;
        }

        /// <summary>
        /// Checks if a room number already exists
        /// </summary>
        public static bool RoomNumberExists(string roomNumber, int excludeRoomId = 0)
        {
            string query = "SELECT COUNT(*) FROM Rooms WHERE RoomNumber = @RoomNumber AND RoomID != @ExcludeRoomID";
            SqlParameter[] parameters = {
                new SqlParameter("@RoomNumber", roomNumber),
                new SqlParameter("@ExcludeRoomID", excludeRoomId)
            };

            int count = Convert.ToInt32(DatabaseHelper.ExecuteScalar(query, parameters));
            return count > 0;
        }

        /// <summary>
        /// Adds a new room
        /// </summary>
        public static bool AddRoom(Room room)
        {
            string query = "INSERT INTO Rooms (RoomNumber, RoomType, PricePerNight, IsAvailable) VALUES (@RoomNumber, @RoomType, @PricePerNight, @IsAvailable)";
            SqlParameter[] parameters = {
                new SqlParameter("@RoomNumber", room.RoomNumber),
                new SqlParameter("@RoomType", room.RoomType),
                new SqlParameter("@PricePerNight", room.PricePerNight),
                new SqlParameter("@IsAvailable", room.IsAvailable)
            };

            return DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        /// <summary>
        /// Updates an existing room
        /// </summary>
        public static bool UpdateRoom(Room room)
        {
            string query = "UPDATE Rooms SET RoomNumber = @RoomNumber, RoomType = @RoomType, PricePerNight = @PricePerNight, IsAvailable = @IsAvailable WHERE RoomID = @RoomID";
            SqlParameter[] parameters = {
                new SqlParameter("@RoomID", room.RoomID),
                new SqlParameter("@RoomNumber", room.RoomNumber),
                new SqlParameter("@RoomType", room.RoomType),
                new SqlParameter("@PricePerNight", room.PricePerNight),
                new SqlParameter("@IsAvailable", room.IsAvailable)
            };

            return DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        /// <summary>
        /// Deletes a room
        /// </summary>
        public static bool DeleteRoom(int roomId)
        {
            // Check if room has active reservations
            string checkQuery = "SELECT COUNT(*) FROM Reservations WHERE RoomID = @RoomID AND Status IN ('Booked', 'CheckedIn')";
            SqlParameter[] checkParams = {
                new SqlParameter("@RoomID", roomId)
            };

            int reservationCount = Convert.ToInt32(DatabaseHelper.ExecuteScalar(checkQuery, checkParams));
            if (reservationCount > 0)
            {
                throw new Exception("Cannot delete room with active reservations.");
            }

            string query = "DELETE FROM Rooms WHERE RoomID = @RoomID";
            SqlParameter[] parameters = {
                new SqlParameter("@RoomID", roomId)
            };

            return DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;
        }

        /// <summary>
        /// Updates room availability status
        /// </summary>
        public static bool UpdateRoomAvailability(int roomId, bool isAvailable)
        {
            string query = "UPDATE Rooms SET IsAvailable = @IsAvailable WHERE RoomID = @RoomID";
            SqlParameter[] parameters = {
                new SqlParameter("@RoomID", roomId),
                new SqlParameter("@IsAvailable", isAvailable)
            };

            return DatabaseHelper.ExecuteNonQuery(query, parameters) > 0;
        }
    }
}
