using System;

namespace HotelManagementSystem.Models
{
    /// <summary>
    /// Represents a payment entity
    /// </summary>
    public class Payment
    {
        public int PaymentID { get; set; }
        public int ReservationID { get; set; }
        public DateTime PaymentDate { get; set; }
        public decimal Amount { get; set; }
        public string PaymentMethod { get; set; }

        // Navigation properties (for display purposes)
        public string CustomerName { get; set; }
        public string RoomNumber { get; set; }

        public Payment()
        {
            PaymentMethod = "Cash";
            CustomerName = string.Empty;
            RoomNumber = string.Empty;
        }
    }
}
