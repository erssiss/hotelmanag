using System;

namespace HotelManagementSystem.Models
{
    /// <summary>
    /// Represents a hotel room entity
    /// </summary>
    public class Room
    {
        public int RoomID { get; set; }
        public string RoomNumber { get; set; }
        public string RoomType { get; set; }
        public decimal PricePerNight { get; set; }
        public bool IsAvailable { get; set; }

        public Room()
        {
            RoomNumber = string.Empty;
            RoomType = string.Empty;
        }

        public Room(string roomNumber, string roomType, decimal pricePerNight, bool isAvailable)
        {
            RoomNumber = roomNumber;
            RoomType = roomType;
            PricePerNight = pricePerNight;
            IsAvailable = isAvailable;
        }
    }
}
