using System;

namespace HotelManagementSystem.Models
{
    /// <summary>
    /// Represents a customer entity
    /// </summary>
    public class Customer
    {
        public int CustomerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string IDNumber { get; set; }

        public Customer()
        {
            FirstName = string.Empty;
            LastName = string.Empty;
            Phone = string.Empty;
            Email = string.Empty;
            IDNumber = string.Empty;
        }

        public string FullName => $"{FirstName} {LastName}";
    }
}
