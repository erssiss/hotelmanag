using System;

namespace HotelManagementSystem.Models
{
    /// <summary>
    /// Represents a reservation entity
    /// </summary>
    public class Reservation
    {
        public int ReservationID { get; set; }
        public int CustomerID { get; set; }
        public int RoomID { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public decimal TotalPrice { get; set; }
        public string Status { get; set; }

        // Actual check-in / check-out timestamps
        public DateTime? ActualCheckIn { get; set; }
        public DateTime? ActualCheckOut { get; set; }

        // Navigation properties (for display purposes)
        public string CustomerName { get; set; }
        public string RoomNumber { get; set; }

        public Reservation()
        {
            Status = "Booked";
            CustomerName = string.Empty;
            RoomNumber = string.Empty;
        }

        public int NumberOfNights => (CheckOutDate - CheckInDate).Days;
    }
}
