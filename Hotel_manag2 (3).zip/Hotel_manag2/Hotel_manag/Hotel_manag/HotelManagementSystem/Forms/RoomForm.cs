using System;
using System.Data;
using System.Windows.Forms;
using HotelManagementSystem.DAL;
using HotelManagementSystem.Models;

namespace HotelManagementSystem.Forms
{
    public partial class RoomForm : Form
    {
        private bool isEditMode = false;
        private int selectedRoomId = 0;

        public RoomForm()
        {
            InitializeComponent();
            CenterRoomLayout();
        }

        private void RoomForm_Load(object sender, EventArgs e)
        {
            LoadRooms();
            LoadRoomTypes();
            ClearFields();
            CenterRoomLayout();
        }

        private void RoomForm_Resize(object sender, EventArgs e)
        {
            CenterRoomLayout();
        }

        private void CenterRoomLayout()
        {
            // Keep the same top layout, but stretch/center horizontally for fullscreen
            const int sidePadding = 27;
            int w = this.ClientSize.Width;
            int h = this.ClientSize.Height;
            if (w <= sidePadding * 2 || h <= 0)
                return;

            int contentWidth = w - (sidePadding * 2);

            dgvRooms.Left = sidePadding;
            dgvRooms.Width = contentWidth;

            // Keep refresh button right-aligned with the grid
            btnRefresh.Left = dgvRooms.Right - btnRefresh.Width;

            groupBoxDetails.Left = sidePadding;
            groupBoxDetails.Width = contentWidth;

            // Center the bottom action buttons as a row
            int gap = 14;
            int buttonsTotalWidth =
                btnAdd.Width + btnSave.Width + btnEdit.Width + btnDelete.Width + btnCancel.Width +
                (gap * 4);

            int startX = Math.Max(sidePadding, (w - buttonsTotalWidth) / 2);
            int y = btnAdd.Top; // keep current vertical position

            btnAdd.Left = startX;
            btnAdd.Top = y;

            btnSave.Left = btnAdd.Right + gap;
            btnSave.Top = y;

            btnEdit.Left = btnSave.Right + gap;
            btnEdit.Top = y;

            btnDelete.Left = btnEdit.Right + gap;
            btnDelete.Top = y;

            btnCancel.Left = btnDelete.Right + gap;
            btnCancel.Top = y;
        }

        private void LoadRooms()
        {
            try
            {
                DataTable rooms = RoomDAL.GetAllRooms();
                dgvRooms.DataSource = rooms;
                dgvRooms.Columns["RoomID"].Visible = false;
                dgvRooms.Columns["RoomNumber"].HeaderText = "Room Number";
                dgvRooms.Columns["RoomType"].HeaderText = "Room Type";
                dgvRooms.Columns["PricePerNight"].HeaderText = "Price/Night";
                dgvRooms.Columns["IsAvailable"].HeaderText = "Available";
                dgvRooms.Columns["PricePerNight"].DefaultCellStyle.Format = "C2";
                
                // Color coding for availability
                foreach (DataGridViewRow row in dgvRooms.Rows)
                {
                    bool isAvailable = Convert.ToBoolean(row.Cells["IsAvailable"].Value);
                    row.DefaultCellStyle.BackColor = isAvailable ? System.Drawing.Color.LightGreen : System.Drawing.Color.LightCoral;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading rooms: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadRoomTypes()
        {
            cmbRoomType.Items.Clear();
            cmbRoomType.Items.Add("Single");
            cmbRoomType.Items.Add("Double");
            cmbRoomType.Items.Add("Suite");
        }

        private void ClearFields()
        {
            txtRoomNumber.Clear();
            cmbRoomType.SelectedIndex = -1;
            txtPricePerNight.Clear();
            chkIsAvailable.Checked = true;
            isEditMode = false;
            selectedRoomId = 0;
            btnSave.Text = "Add Room";
            btnCancel.Enabled = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ClearFields();
            btnCancel.Enabled = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // Validation
                if (string.IsNullOrWhiteSpace(txtRoomNumber.Text))
                {
                    MessageBox.Show("Please enter room number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtRoomNumber.Focus();
                    return;
                }

                if (cmbRoomType.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select room type.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cmbRoomType.Focus();
                    return;
                }

                if (!decimal.TryParse(txtPricePerNight.Text, out decimal price) || price <= 0)
                {
                    MessageBox.Show("Please enter a valid price per night.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtPricePerNight.Focus();
                    return;
                }

                Room room = new Room
                {
                    RoomNumber = txtRoomNumber.Text.Trim(),
                    RoomType = cmbRoomType.SelectedItem.ToString(),
                    PricePerNight = price,
                    IsAvailable = chkIsAvailable.Checked
                };

                if (isEditMode)
                {
                    // Check for duplicate room number
                    if (RoomDAL.RoomNumberExists(room.RoomNumber, selectedRoomId))
                    {
                        MessageBox.Show("Room number already exists.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    room.RoomID = selectedRoomId;
                    if (RoomDAL.UpdateRoom(room))
                    {
                        MessageBox.Show("Room updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadRooms();
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update room.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    // Check for duplicate room number
                    if (RoomDAL.RoomNumberExists(room.RoomNumber))
                    {
                        MessageBox.Show("Room number already exists.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (RoomDAL.AddRoom(room))
                    {
                        MessageBox.Show("Room added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadRooms();
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("Failed to add room.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvRooms.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a room to edit.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                selectedRoomId = Convert.ToInt32(dgvRooms.SelectedRows[0].Cells["RoomID"].Value);
                Room room = RoomDAL.GetRoomById(selectedRoomId);

                if (room != null)
                {
                    txtRoomNumber.Text = room.RoomNumber;
                    cmbRoomType.Text = room.RoomType;
                    txtPricePerNight.Text = room.PricePerNight.ToString("F2");
                    chkIsAvailable.Checked = room.IsAvailable;

                    isEditMode = true;
                    btnSave.Text = "Update Room";
                    btnCancel.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading room: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvRooms.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a room to delete.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show(
                "Are you sure you want to delete this room?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    int roomId = Convert.ToInt32(dgvRooms.SelectedRows[0].Cells["RoomID"].Value);
                    RoomDAL.DeleteRoom(roomId);
                    MessageBox.Show("Room deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadRooms();
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting room: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadRooms();
        }

        private void dgvRooms_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                btnEdit_Click(sender, EventArgs.Empty);
            }
        }

        private void dgvRooms_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
