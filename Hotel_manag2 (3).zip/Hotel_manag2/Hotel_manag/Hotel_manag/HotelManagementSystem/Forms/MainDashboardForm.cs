using System;
using System.Windows.Forms;
using HotelManagementSystem.DAL;

namespace HotelManagementSystem.Forms
{
    public partial class MainDashboardForm : Form
    {
        public MainDashboardForm()
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.WindowState = FormWindowState.Normal;
            this.Visible = true;
            CenterDashboardLayout();
        }

        private void MainDashboardForm_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = $"Welcome, Admin! - {DateTime.Now:dddd, MMMM dd, yyyy}";
            LoadDashboardStats();
        }

        private void MainDashboardForm_Shown(object sender, EventArgs e)
        {
            // Ensure form is visible and active
            this.WindowState = FormWindowState.Normal;
            this.Visible = true;
            this.Show();
            this.Activate();
            this.BringToFront();
            this.Focus();
            CenterDashboardLayout();
        }

        private void MainDashboardForm_Resize(object sender, EventArgs e)
        {
            CenterDashboardLayout();
        }

        private void CenterDashboardLayout()
        {
            if (panelMain == null || panelMain.IsDisposed)
                return;

            // Two-column button grid width:
            // left button (220) + gap (32) + right button (220) = 472
            const int contentMinWidth = 472;
            int availableWidth = panelMain.ClientSize.Width;
            if (availableWidth <= 0)
                return;

            int leftBase = Math.Max(0, (availableWidth - contentMinWidth) / 2);

            // Keep the original vertical layout, just center horizontally
            btnRooms.Left = leftBase;
            btnReservations.Left = leftBase;

            btnCustomers.Left = leftBase + 252; // 220 + 32 gap
            btnPayments.Left = leftBase + 252;

            // Stats group aligns with the button grid
            grpStats.Left = leftBase;
            grpStats.Width = Math.Max(contentMinWidth, availableWidth - (leftBase * 2));

            // Exit button centered under stats
            btnExit.Left = Math.Max(0, (availableWidth - btnExit.Width) / 2);
        }

        private void LoadDashboardStats()
        {
            try
            {
                int totalRooms = RoomDAL.GetRoomCount();
                int availableRooms = RoomDAL.GetAvailableRoomCount();
                int totalCustomers = CustomerDAL.GetCustomerCount();
                int activeReservations = ReservationDAL.GetActiveReservationCount();

                lblRoomStats.Text = $"Rooms: {availableRooms} available / {totalRooms} total";
                lblCustomerStats.Text = $"Customers: {totalCustomers}";
                lblReservationStats.Text = $"Active reservations: {activeReservations}";
            }
            catch (Exception ex)
            {
                // Log error but don't prevent form from showing
                lblRoomStats.Text = "Rooms: n/a";
                lblCustomerStats.Text = "Customers: n/a";
                lblReservationStats.Text = "Active reservations: n/a";
                System.Diagnostics.Debug.WriteLine($"Error loading dashboard stats: {ex.Message}");
            }
        }

        private void btnRefreshStats_Click(object sender, EventArgs e)
        {
            LoadDashboardStats();
        }

        private void MainDashboardForm_KeyDown(object sender, KeyEventArgs e)
        {
            // Global keyboard shortcuts from dashboard
            if (e.Control && e.KeyCode == Keys.R)
            {
                btnRooms.PerformClick();
                e.Handled = true;
            }
            else if (e.Control && e.KeyCode == Keys.C)
            {
                btnCustomers.PerformClick();
                e.Handled = true;
            }
            else if (e.Control && e.KeyCode == Keys.B) // B for Bookings (Reservations)
            {
                btnReservations.PerformClick();
                e.Handled = true;
            }
            else if (e.Control && e.KeyCode == Keys.P)
            {
                btnPayments.PerformClick();
                e.Handled = true;
            }
            else if (e.Control && e.KeyCode == Keys.Q)
            {
                btnExit.PerformClick();
                e.Handled = true;
            }
        }

        private void btnRooms_Click(object sender, EventArgs e)
        {
            RoomForm roomForm = new RoomForm();
            roomForm.ShowDialog();
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            CustomerForm customerForm = new CustomerForm();
            customerForm.ShowDialog();
        }

        private void btnReservations_Click(object sender, EventArgs e)
        {
            ReservationForm reservationForm = new ReservationForm();
            reservationForm.ShowDialog();
        }

        private void btnPayments_Click(object sender, EventArgs e)
        {
            PaymentForm paymentForm = new PaymentForm();
            paymentForm.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to exit?",
                "Confirm Exit",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void MainDashboardForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Are you sure you want to exit?",
                "Confirm Exit",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
            else
            {
                // Ensure application exits when main form closes
                Application.Exit();
            }
        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
