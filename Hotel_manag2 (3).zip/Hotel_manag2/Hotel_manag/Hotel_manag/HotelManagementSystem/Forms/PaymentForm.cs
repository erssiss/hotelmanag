using System;
using System.Data;
using System.Windows.Forms;
using HotelManagementSystem.DAL;
using HotelManagementSystem.Models;

namespace HotelManagementSystem.Forms
{
    public partial class PaymentForm : Form
    {
        private bool isEditMode = false;
        private int selectedPaymentId = 0;

        public PaymentForm()
        {
            InitializeComponent();
        }

        private void PaymentForm_Load(object sender, EventArgs e)
        {
            LoadPayments();
            LoadReservations();
            LoadPaymentMethods();
            ClearFields();
        }

        private void LoadPayments()
        {
            try
            {
                DataTable payments = PaymentDAL.GetAllPayments();
                dgvPayments.DataSource = payments;
                dgvPayments.Columns["PaymentID"].Visible = false;
                dgvPayments.Columns["ReservationID"].Visible = false;
                dgvPayments.Columns["CustomerName"].HeaderText = "Customer";
                dgvPayments.Columns["RoomNumber"].HeaderText = "Room";
                dgvPayments.Columns["PaymentDate"].HeaderText = "Payment Date";
                dgvPayments.Columns["Amount"].HeaderText = "Amount";
                dgvPayments.Columns["PaymentMethod"].HeaderText = "Method";
                dgvPayments.Columns["Amount"].DefaultCellStyle.Format = "C2";
                dgvPayments.Columns["PaymentDate"].DefaultCellStyle.Format = "MM/dd/yyyy HH:mm";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading payments: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadReservations()
        {
            try
            {
                DataTable reservations = ReservationDAL.GetAllReservations();
                // Add a computed column for display
                reservations.Columns.Add("DisplayText", typeof(string), "CustomerName + ' - Room ' + RoomNumber + ' (' + Status + ')'");
                cmbReservation.DataSource = reservations;
                cmbReservation.DisplayMember = "DisplayText";
                cmbReservation.ValueMember = "ReservationID";
                cmbReservation.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading reservations: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadPaymentMethods()
        {
            cmbPaymentMethod.Items.Clear();
            cmbPaymentMethod.Items.Add("Cash");
            cmbPaymentMethod.Items.Add("Card");
        }

        private void ClearFields()
        {
            cmbReservation.SelectedIndex = -1;
            dtpPaymentDate.Value = DateTime.Now;
            txtAmount.Clear();
            cmbPaymentMethod.SelectedIndex = -1;
            lblReservationInfo.Text = "";
            isEditMode = false;
            selectedPaymentId = 0;
            btnSave.Text = "Record Payment";
            btnCancel.Enabled = false;
        }

        private void cmbReservation_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbReservation.SelectedValue != null)
            {
                try
                {
                    int reservationId = Convert.ToInt32(cmbReservation.SelectedValue);
                    Reservation reservation = ReservationDAL.GetReservationById(reservationId);
                    if (reservation != null)
                    {
                        decimal totalPaid = PaymentDAL.GetTotalPaidForReservation(reservationId);
                        decimal remaining = reservation.TotalPrice - totalPaid;
                        lblReservationInfo.Text = $"Total: {reservation.TotalPrice:C2} | Paid: {totalPaid:C2} | Remaining: {remaining:C2}";
                    }
                }
                catch
                {
                    lblReservationInfo.Text = "";
                }
            }
            else
            {
                lblReservationInfo.Text = "";
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ClearFields();
            LoadReservations();
            btnCancel.Enabled = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // Validation
                if (cmbReservation.SelectedValue == null)
                {
                    MessageBox.Show("Please select a reservation.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cmbReservation.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtAmount.Text) || !decimal.TryParse(txtAmount.Text, out decimal amount) || amount <= 0)
                {
                    MessageBox.Show("Please enter a valid payment amount.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtAmount.Focus();
                    return;
                }

                if (cmbPaymentMethod.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select a payment method.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cmbPaymentMethod.Focus();
                    return;
                }

                Payment payment = new Payment
                {
                    ReservationID = Convert.ToInt32(cmbReservation.SelectedValue),
                    PaymentDate = dtpPaymentDate.Value,
                    Amount = amount,
                    PaymentMethod = cmbPaymentMethod.SelectedItem.ToString()
                };

                if (isEditMode)
                {
                    payment.PaymentID = selectedPaymentId;
                    if (PaymentDAL.UpdatePayment(payment))
                    {
                        MessageBox.Show("Payment updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadPayments();
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update payment.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    if (PaymentDAL.AddPayment(payment))
                    {
                        MessageBox.Show("Payment recorded successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadPayments();
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("Failed to record payment.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvPayments.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a payment to edit.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                selectedPaymentId = Convert.ToInt32(dgvPayments.SelectedRows[0].Cells["PaymentID"].Value);
                Payment payment = PaymentDAL.GetPaymentById(selectedPaymentId);

                if (payment != null)
                {
                    cmbReservation.SelectedValue = payment.ReservationID;
                    dtpPaymentDate.Value = payment.PaymentDate;
                    txtAmount.Text = payment.Amount.ToString("F2");
                    cmbPaymentMethod.Text = payment.PaymentMethod;

                    isEditMode = true;
                    btnSave.Text = "Update Payment";
                    btnCancel.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading payment: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvPayments.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a payment to delete.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show(
                "Are you sure you want to delete this payment?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    int paymentId = Convert.ToInt32(dgvPayments.SelectedRows[0].Cells["PaymentID"].Value);
                    PaymentDAL.DeletePayment(paymentId);
                    MessageBox.Show("Payment deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadPayments();
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting payment: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadPayments();
            LoadReservations();
        }

        private void dgvPayments_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                btnEdit_Click(sender, EventArgs.Empty);
            }
        }

        private void btnViewHistory_Click(object sender, EventArgs e)
        {
            if (cmbReservation.SelectedValue == null)
            {
                MessageBox.Show("Please select a reservation to view payment history.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                int reservationId = Convert.ToInt32(cmbReservation.SelectedValue);
                DataTable payments = PaymentDAL.GetPaymentsByReservation(reservationId);
                
                string history = "Payment History:\n\n";
                decimal totalPaid = 0;
                foreach (DataRow row in payments.Rows)
                {
                    history += $"Date: {Convert.ToDateTime(row["PaymentDate"]):MM/dd/yyyy HH:mm}\n";
                    history += $"Amount: {Convert.ToDecimal(row["Amount"]):C2}\n";
                    history += $"Method: {row["PaymentMethod"]}\n";
                    history += "---\n";
                    totalPaid += Convert.ToDecimal(row["Amount"]);
                }
                history += $"\nTotal Paid: {totalPaid:C2}";

                MessageBox.Show(history, "Payment History", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading payment history: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
