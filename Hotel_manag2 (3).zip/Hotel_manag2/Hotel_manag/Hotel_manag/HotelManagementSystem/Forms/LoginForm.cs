using System;
using System.Windows.Forms;
using HotelManagementSystem.DAL;

namespace HotelManagementSystem.Forms
{
    public partial class LoginForm : Form
    {
        // Simple authentication - in production, use proper authentication with hashed passwords
        private const string VALID_USERNAME = "admin";
        private const string VALID_PASSWORD = "admin123";

        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            // Test database connection
            if (!DatabaseHelper.TestConnection())
            {
                MessageBox.Show(
                    "Cannot connect to database. Please ensure SQL Server LocalDB is installed and the database is created.\n\n" +
                    "Run the CreateDatabase.sql script first.",
                    "Database Connection Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string username = txtUsername.Text.Trim();
                string password = txtPassword.Text;

                // Validate input
                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Please enter both username and password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Simple authentication
                if (username == VALID_USERNAME && password == VALID_PASSWORD)
                {
                    // Test database connection before proceeding
                    if (!DatabaseHelper.TestConnection())
                    {
                        MessageBox.Show(
                            "Cannot connect to database. Please ensure the database is created and accessible.",
                            "Database Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                        return;
                    }

                    // Open main dashboard
                    try
                    {
                        MainDashboardForm dashboard = new MainDashboardForm();
                        this.Hide();
                        dashboard.Show();
                        dashboard.WindowState = FormWindowState.Normal;
                        dashboard.Activate();
                        dashboard.BringToFront();
                        dashboard.Focus();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error opening dashboard: {ex.Message}\n\nStack trace: {ex.StackTrace}", 
                            "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        this.Show(); // Show login form again if dashboard fails
                    }
                }
                else
                {
                    MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPassword.Clear();
                    txtUsername.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin_Click(sender, e);
            }
        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            // Toggle password visibility
            txtPassword.PasswordChar = chkShowPassword.Checked ? '\0' : '*';
        }
    }
}
