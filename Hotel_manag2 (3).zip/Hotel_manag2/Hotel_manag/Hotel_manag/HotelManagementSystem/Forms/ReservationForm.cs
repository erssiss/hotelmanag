using System;
using System.Data;
using System.Windows.Forms;
using HotelManagementSystem.DAL;
using HotelManagementSystem.Models;

namespace HotelManagementSystem.Forms
{
    public partial class ReservationForm : Form
    {
        private bool isEditMode = false;
        private int selectedReservationId = 0;

        public ReservationForm()
        {
            InitializeComponent();
        }

        private void ReservationForm_Load(object sender, EventArgs e)
        {
            LoadReservations();
            LoadCustomers();
            LoadRooms();
            LoadStatuses();
            ClearFields();
        }

        private void LoadReservations()
        {
            try
            {
                DataTable reservations = ReservationDAL.GetAllReservations();
                dgvReservations.DataSource = reservations;
                dgvReservations.Columns["ReservationID"].Visible = false;
                dgvReservations.Columns["CustomerID"].Visible = false;
                dgvReservations.Columns["RoomID"].Visible = false;
                dgvReservations.Columns["CustomerName"].HeaderText = "Customer";
                dgvReservations.Columns["RoomNumber"].HeaderText = "Room";
                dgvReservations.Columns["CheckInDate"].HeaderText = "Check-In";
                dgvReservations.Columns["CheckOutDate"].HeaderText = "Check-Out";
                dgvReservations.Columns["TotalPrice"].HeaderText = "Total Price";
                dgvReservations.Columns["Status"].HeaderText = "Status";
                dgvReservations.Columns["TotalPrice"].DefaultCellStyle.Format = "C2";
                dgvReservations.Columns["CheckInDate"].DefaultCellStyle.Format = "MM/dd/yyyy";
                dgvReservations.Columns["CheckOutDate"].DefaultCellStyle.Format = "MM/dd/yyyy";

                // Optional: show actual check-in/out if present
                if (dgvReservations.Columns.Contains("ActualCheckIn"))
                {
                    dgvReservations.Columns["ActualCheckIn"].HeaderText = "Actual Check-In";
                    dgvReservations.Columns["ActualCheckIn"].DefaultCellStyle.Format = "MM/dd/yyyy HH:mm";
                }
                if (dgvReservations.Columns.Contains("ActualCheckOut"))
                {
                    dgvReservations.Columns["ActualCheckOut"].HeaderText = "Actual Check-Out";
                    dgvReservations.Columns["ActualCheckOut"].DefaultCellStyle.Format = "MM/dd/yyyy HH:mm";
                }

                // Color coding for status
                foreach (DataGridViewRow row in dgvReservations.Rows)
                {
                    string status = row.Cells["Status"].Value?.ToString() ?? "";
                    if (status == "CheckedIn")
                        row.DefaultCellStyle.BackColor = System.Drawing.Color.LightBlue;
                    else if (status == "CheckedOut")
                        row.DefaultCellStyle.BackColor = System.Drawing.Color.LightGray;
                    else if (status == "Cancelled")
                        row.DefaultCellStyle.BackColor = System.Drawing.Color.LightCoral;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading reservations: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadCustomers()
        {
            try
            {
                DataTable customers = CustomerDAL.GetAllCustomers();
                // Add a computed column for full name
                customers.Columns.Add("FullName", typeof(string), "FirstName + ' ' + LastName");
                cmbCustomer.DataSource = customers;
                cmbCustomer.DisplayMember = "FullName";
                cmbCustomer.ValueMember = "CustomerID";
                cmbCustomer.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading customers: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadRooms()
        {
            try
            {
                DataTable rooms = RoomDAL.GetAvailableRooms();
                cmbRoom.DataSource = rooms;
                cmbRoom.DisplayMember = "RoomNumber";
                cmbRoom.ValueMember = "RoomID";
                cmbRoom.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading rooms: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadStatuses()
        {
            cmbStatus.Items.Clear();
            cmbStatus.Items.Add("Booked");
            cmbStatus.Items.Add("CheckedIn");
            cmbStatus.Items.Add("CheckedOut");
            cmbStatus.Items.Add("Cancelled");
        }

        private void ClearFields()
        {
            cmbCustomer.SelectedIndex = -1;
            cmbRoom.SelectedIndex = -1;
            dtpCheckIn.Value = DateTime.Now;
            dtpCheckOut.Value = DateTime.Now.AddDays(1);
            txtTotalPrice.Clear();
            cmbStatus.SelectedIndex = -1;
            isEditMode = false;
            selectedReservationId = 0;
            btnSave.Text = "Create Reservation";
            btnCancel.Enabled = false;
        }

        private void CalculateTotalPrice()
        {
            try
            {
                if (cmbRoom.SelectedValue != null && dtpCheckIn.Value < dtpCheckOut.Value)
                {
                    int roomId = Convert.ToInt32(cmbRoom.SelectedValue);
                    decimal totalPrice = ReservationDAL.CalculateTotalPrice(roomId, dtpCheckIn.Value, dtpCheckOut.Value);
                    txtTotalPrice.Text = totalPrice.ToString("F2");
                }
                else
                {
                    txtTotalPrice.Clear();
                }
            }
            catch
            {
                txtTotalPrice.Clear();
            }
        }

        private void dtpCheckIn_ValueChanged(object sender, EventArgs e)
        {
            if (dtpCheckIn.Value >= dtpCheckOut.Value)
            {
                dtpCheckOut.Value = dtpCheckIn.Value.AddDays(1);
            }
            CalculateTotalPrice();
        }

        private void dtpCheckOut_ValueChanged(object sender, EventArgs e)
        {
            if (dtpCheckOut.Value <= dtpCheckIn.Value)
            {
                MessageBox.Show("Check-out date must be after check-in date.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dtpCheckOut.Value = dtpCheckIn.Value.AddDays(1);
            }
            CalculateTotalPrice();
        }

        private void cmbRoom_SelectedIndexChanged(object sender, EventArgs e)
        {
            CalculateTotalPrice();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ClearFields();
            LoadRooms(); // Refresh available rooms
            btnCancel.Enabled = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // Validation
                if (cmbCustomer.SelectedValue == null)
                {
                    MessageBox.Show("Please select a customer.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cmbCustomer.Focus();
                    return;
                }

                if (cmbRoom.SelectedValue == null)
                {
                    MessageBox.Show("Please select a room.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cmbRoom.Focus();
                    return;
                }

                if (dtpCheckOut.Value <= dtpCheckIn.Value)
                {
                    MessageBox.Show("Check-out date must be after check-in date.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (cmbStatus.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select a status.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cmbStatus.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtTotalPrice.Text) || !decimal.TryParse(txtTotalPrice.Text, out decimal totalPrice) || totalPrice <= 0)
                {
                    MessageBox.Show("Please calculate total price first.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Reservation reservation = new Reservation
                {
                    CustomerID = Convert.ToInt32(cmbCustomer.SelectedValue),
                    RoomID = Convert.ToInt32(cmbRoom.SelectedValue),
                    CheckInDate = dtpCheckIn.Value,
                    CheckOutDate = dtpCheckOut.Value,
                    TotalPrice = totalPrice,
                    Status = cmbStatus.SelectedItem.ToString()
                };

                if (isEditMode)
                {
                    reservation.ReservationID = selectedReservationId;
                    if (ReservationDAL.UpdateReservation(reservation))
                    {
                        MessageBox.Show("Reservation updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadReservations();
                        LoadRooms();
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update reservation.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    if (ReservationDAL.AddReservation(reservation))
                    {
                        MessageBox.Show("Reservation created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadReservations();
                        LoadRooms();
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("Failed to create reservation.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvReservations.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a reservation to edit.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                selectedReservationId = Convert.ToInt32(dgvReservations.SelectedRows[0].Cells["ReservationID"].Value);
                Reservation reservation = ReservationDAL.GetReservationById(selectedReservationId);

                if (reservation != null)
                {
                    cmbCustomer.SelectedValue = reservation.CustomerID;
                    cmbRoom.SelectedValue = reservation.RoomID;
                    dtpCheckIn.Value = reservation.CheckInDate;
                    dtpCheckOut.Value = reservation.CheckOutDate;
                    txtTotalPrice.Text = reservation.TotalPrice.ToString("F2");
                    cmbStatus.Text = reservation.Status;

                    isEditMode = true;
                    btnSave.Text = "Update Reservation";
                    btnCancel.Enabled = true;

                    // Load all rooms for editing (not just available)
                    DataTable allRooms = RoomDAL.GetAllRooms();
                    cmbRoom.DataSource = allRooms;
                    cmbRoom.DisplayMember = "RoomNumber";
                    cmbRoom.ValueMember = "RoomID";
                    cmbRoom.SelectedValue = reservation.RoomID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading reservation: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvReservations.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a reservation to delete.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show(
                "Are you sure you want to delete this reservation?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    int reservationId = Convert.ToInt32(dgvReservations.SelectedRows[0].Cells["ReservationID"].Value);
                    ReservationDAL.DeleteReservation(reservationId);
                    MessageBox.Show("Reservation deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadReservations();
                    LoadRooms();
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting reservation: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearFields();
            LoadRooms();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadReservations();
            LoadRooms();
        }

        private void dgvReservations_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                btnEdit_Click(sender, EventArgs.Empty);
            }
        }

        private void btnCheckIn_Click(object sender, EventArgs e)
        {
            if (dgvReservations.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a reservation to check in.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                int reservationId = Convert.ToInt32(dgvReservations.SelectedRows[0].Cells["ReservationID"].Value);
                string status = dgvReservations.SelectedRows[0].Cells["Status"].Value?.ToString() ?? string.Empty;

                if (!string.Equals(status, "Booked", StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Only reservations with status 'Booked' can be checked in.", "Invalid Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                ReservationDAL.CheckInReservation(reservationId);
                MessageBox.Show("Guest checked in successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadReservations();
                LoadRooms();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error during check-in: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            if (dgvReservations.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a reservation to check out.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                int reservationId = Convert.ToInt32(dgvReservations.SelectedRows[0].Cells["ReservationID"].Value);
                string status = dgvReservations.SelectedRows[0].Cells["Status"].Value?.ToString() ?? string.Empty;

                if (!string.Equals(status, "CheckedIn", StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Only reservations with status 'CheckedIn' can be checked out.", "Invalid Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                ReservationDAL.CheckOutReservation(reservationId);

                // TODO: trigger invoice generation and payment workflow here

                MessageBox.Show("Guest checked out successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadReservations();
                LoadRooms();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error during check-out: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
