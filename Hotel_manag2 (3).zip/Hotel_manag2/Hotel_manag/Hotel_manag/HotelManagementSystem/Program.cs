using System;
using System.Windows.Forms;
using HotelManagementSystem.Forms;

namespace HotelManagementSystem
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            // Start with Login Form
            Application.Run(new LoginForm());
        }
    }
}
