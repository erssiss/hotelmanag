# Hotel Management System

A complete, production-ready Hotel Management System built with C# Windows Forms (.NET Framework) and SQL Server.

## 📋 Features

### 🔐 Authentication
- Secure login system
- Database connection validation
- Prevents unauthorized access

### 🏨 Room Management
- Add, Edit, Delete rooms
- View all rooms with availability status
- Color-coded availability indicators
- Room types: Single, Double, Suite
- Automatic availability updates

### 👤 Customer Management
- Add, Edit, Delete customers
- Search customers by name or phone
- View customer details
- DataGridView display

### 📅 Reservation Management
- Create and manage reservations
- Select customer and room from dropdowns
- Date pickers for check-in/check-out
- Automatic price calculation (nights × room price)
- Prevents booking unavailable rooms
- Status management (Booked, CheckedIn, CheckedOut, Cancelled)
- Color-coded status indicators

### 💳 Payment System
- Record payments for reservations
- Payment methods: Cash, Card
- View payment history per reservation
- Track total paid vs. remaining balance
- Link payments to reservations

## 🏗️ Architecture

### Layered Structure
```
HotelManagementSystem/
├── Models/          # Entity classes (Room, Customer, Reservation, Payment)
├── DAL/             # Data Access Layer (DatabaseHelper, RoomDAL, CustomerDAL, etc.)
├── Forms/           # UI Layer (LoginForm, MainDashboardForm, etc.)
└── Properties/      # Application properties and resources
```

### Database Design
- **Database**: HotelManagementDB
- **Tables**: Rooms, Customers, Reservations, Payments
- **Features**: Foreign keys, constraints, sample seed data

## 🚀 Getting Started

### Prerequisites
- Visual Studio 2019 or later
- .NET Framework 4.8
- SQL Server LocalDB or SQL Server Express
- Windows OS

### Installation Steps

1. **Create the Database**
   - Open SQL Server Management Studio (SSMS) or use sqlcmd
   - Execute the script: `Database/CreateDatabase.sql`
   - This will create the database and populate it with sample data

2. **Configure Connection String**
   - Open `HotelManagementSystem/App.config`
   - Verify the connection string matches your SQL Server setup:
   ```xml
   <connectionStrings>
     <add name="HotelDB" connectionString="Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=HotelManagementDB;Integrated Security=True;Connect Timeout=30" />
   </connectionStrings>
   ```
   - For SQL Server Express, use:
   ```xml
   <add name="HotelDB" connectionString="Data Source=.\SQLEXPRESS;Initial Catalog=HotelManagementDB;Integrated Security=True;Connect Timeout=30" />
   ```

3. **Open and Build the Project**
   - Open `HotelManagementSystem.sln` in Visual Studio
   - Restore NuGet packages (if any)
   - Build the solution (Ctrl+Shift+B)
   - Run the application (F5)

4. **Login Credentials**
   - Username: `admin`
   - Password: `admin123`

## 📁 Project Structure

```
hotel/
├── Database/
│   ├── CreateDatabase.sql          # Database schema and seed data
│   └── App.config.example          # Example connection string configuration
├── HotelManagementSystem/
│   ├── Models/
│   │   ├── Room.cs
│   │   ├── Customer.cs
│   │   ├── Reservation.cs
│   │   └── Payment.cs
│   ├── DAL/
│   │   ├── DatabaseHelper.cs      # Connection management
│   │   ├── RoomDAL.cs
│   │   ├── CustomerDAL.cs
│   │   ├── ReservationDAL.cs
│   │   └── PaymentDAL.cs
│   ├── Forms/
│   │   ├── LoginForm.cs
│   │   ├── MainDashboardForm.cs
│   │   ├── RoomForm.cs
│   │   ├── CustomerForm.cs
│   │   ├── ReservationForm.cs
│   │   └── PaymentForm.cs
│   ├── Properties/
│   ├── App.config
│   ├── Program.cs
│   └── HotelManagementSystem.csproj
└── README.md
```

## 🔒 Security Features

- **Parameterized Queries**: All database queries use parameters to prevent SQL injection
- **Input Validation**: Comprehensive validation on all user inputs
- **Error Handling**: Try-catch blocks with user-friendly error messages
- **Authentication**: Login required before accessing the system

## ✨ Key Features Implemented

✅ **All Required Features**
- Authentication system
- Room management (CRUD)
- Customer management (CRUD + Search)
- Reservation management (with price calculation)
- Payment system
- DataGridView displays
- Status color indicators
- Date validation
- Input validation
- Error handling

✅ **Best Practices**
- Layered architecture
- Parameterized queries
- Clear naming conventions
- Code comments
- Reusable methods
- Responsive UI layout

## 🎨 UI Features

- Modern, clean Windows Forms interface
- Consistent color scheme
- Color-coded status indicators:
  - Green: Available rooms
  - Red: Unavailable rooms
  - Blue: Checked-in reservations
  - Gray: Checked-out reservations
  - Coral: Cancelled reservations
- User-friendly error messages
- Confirmation dialogs for destructive actions

## 📝 Database Schema

### Rooms Table
- RoomID (PK, Identity)
- RoomNumber (Unique)
- RoomType (Single, Double, Suite)
- PricePerNight
- IsAvailable

### Customers Table
- CustomerID (PK, Identity)
- FirstName, LastName
- Phone, Email, IDNumber

### Reservations Table
- ReservationID (PK, Identity)
- CustomerID (FK)
- RoomID (FK)
- CheckInDate, CheckOutDate
- TotalPrice
- Status

### Payments Table
- PaymentID (PK, Identity)
- ReservationID (FK)
- PaymentDate
- Amount
- PaymentMethod

## 🛠️ Troubleshooting

### Database Connection Issues
1. Ensure SQL Server LocalDB is installed
2. Check the connection string in App.config
3. Verify the database exists: `HotelManagementDB`
4. Run the CreateDatabase.sql script again if needed

### Build Errors
1. Ensure .NET Framework 4.8 is installed
2. Restore NuGet packages
3. Clean and rebuild the solution

## 📄 License

This project is provided as-is for educational and commercial use.

## 👨‍💻 Development Notes

- All database operations use ADO.NET (SqlConnection, SqlCommand, SqlDataAdapter)
- The system automatically updates room availability based on reservations
- Price calculation is automatic: `TotalPrice = NumberOfNights × RoomPrice`
- Foreign key constraints ensure data integrity
- Cascade deletes are configured for related records

## 🔄 Future Enhancements

Potential improvements:
- User roles and permissions
- Reports generation (PDF/Excel)
- Email notifications
- Advanced search and filtering
- Dashboard analytics
- Backup and restore functionality

---

**Built with ❤️ using C# Windows Forms and SQL Server**
