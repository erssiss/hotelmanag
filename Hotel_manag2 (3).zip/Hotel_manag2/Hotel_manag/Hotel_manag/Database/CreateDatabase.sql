-- =============================================
-- Hotel Management System Database Script
-- Database: HotelManagementDB
-- =============================================

-- Create Database
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'HotelManagementDB')
BEGIN
    CREATE DATABASE HotelManagementDB;
END
GO

USE HotelManagementDB;
GO

-- =============================================
-- Table: Rooms
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Rooms]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[Rooms] (
        [RoomID] INT IDENTITY(1,1) PRIMARY KEY,
        [RoomNumber] VARCHAR(10) NOT NULL UNIQUE,
        [RoomType] VARCHAR(50) NOT NULL,
        [PricePerNight] DECIMAL(10,2) NOT NULL,
        [IsAvailable] BIT NOT NULL DEFAULT 1
    );
END
GO

-- =============================================
-- Table: Customers
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Customers]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[Customers] (
        [CustomerID] INT IDENTITY(1,1) PRIMARY KEY,
        [FirstName] VARCHAR(50) NOT NULL,
        [LastName] VARCHAR(50) NOT NULL,
        [Phone] VARCHAR(20) NOT NULL,
        [Email] VARCHAR(100),
        [IDNumber] VARCHAR(50)
    );
END
GO

-- =============================================
-- Table: Reservations
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Reservations]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[Reservations] (
        [ReservationID] INT IDENTITY(1,1) PRIMARY KEY,
        [CustomerID] INT NOT NULL,
        [RoomID] INT NOT NULL,
        [CheckInDate] DATE NOT NULL,
        [CheckOutDate] DATE NOT NULL,
        [TotalPrice] DECIMAL(10,2) NOT NULL,
        [Status] VARCHAR(20) NOT NULL DEFAULT 'Booked',
        [ActualCheckIn] DATETIME NULL,
        [ActualCheckOut] DATETIME NULL,
        CONSTRAINT [FK_Reservations_Customers] FOREIGN KEY ([CustomerID]) 
            REFERENCES [dbo].[Customers]([CustomerID]) ON DELETE CASCADE,
        CONSTRAINT [FK_Reservations_Rooms] FOREIGN KEY ([RoomID]) 
            REFERENCES [dbo].[Rooms]([RoomID]) ON DELETE CASCADE,
        CONSTRAINT [CK_Reservations_Dates] CHECK ([CheckOutDate] > [CheckInDate])
    );
END
GO

-- Ensure new columns exist when running script against an existing database
IF COL_LENGTH('dbo.Reservations', 'ActualCheckIn') IS NULL
BEGIN
    ALTER TABLE dbo.Reservations ADD ActualCheckIn DATETIME NULL;
END
GO

IF COL_LENGTH('dbo.Reservations', 'ActualCheckOut') IS NULL
BEGIN
    ALTER TABLE dbo.Reservations ADD ActualCheckOut DATETIME NULL;
END
GO

-- =============================================
-- Table: Payments
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Payments]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[Payments] (
        [PaymentID] INT IDENTITY(1,1) PRIMARY KEY,
        [ReservationID] INT NOT NULL,
        [PaymentDate] DATETIME NOT NULL DEFAULT GETDATE(),
        [Amount] DECIMAL(10,2) NOT NULL,
        [PaymentMethod] VARCHAR(20) NOT NULL,
        CONSTRAINT [FK_Payments_Reservations] FOREIGN KEY ([ReservationID]) 
            REFERENCES [dbo].[Reservations]([ReservationID]) ON DELETE CASCADE
    );
END
GO

-- =============================================
-- Sample Seed Data
-- =============================================

-- Insert Rooms
IF NOT EXISTS (SELECT * FROM [dbo].[Rooms])
BEGIN
    INSERT INTO [dbo].[Rooms] ([RoomNumber], [RoomType], [PricePerNight], [IsAvailable])
    VALUES 
        ('101', 'Single', 50.00, 1),
        ('102', 'Single', 50.00, 1),
        ('201', 'Double', 80.00, 1),
        ('202', 'Double', 80.00, 1),
        ('301', 'Suite', 150.00, 1),
        ('302', 'Suite', 150.00, 1),
        ('103', 'Single', 50.00, 0),
        ('203', 'Double', 80.00, 0);
END
GO

-- Insert Customers
IF NOT EXISTS (SELECT * FROM [dbo].[Customers])
BEGIN
    INSERT INTO [dbo].[Customers] ([FirstName], [LastName], [Phone], [Email], [IDNumber])
    VALUES 
        ('John', 'Doe', '555-0101', 'john.doe@email.com', 'ID123456'),
        ('Jane', 'Smith', '555-0102', 'jane.smith@email.com', 'ID123457'),
        ('Bob', 'Johnson', '555-0103', 'bob.johnson@email.com', 'ID123458'),
        ('Alice', 'Williams', '555-0104', 'alice.williams@email.com', 'ID123459');
END
GO

-- Insert Reservations
IF NOT EXISTS (SELECT * FROM [dbo].[Reservations])
BEGIN
    INSERT INTO [dbo].[Reservations] ([CustomerID], [RoomID], [CheckInDate], [CheckOutDate], [TotalPrice], [Status])
    VALUES 
        (1, 7, DATEADD(day, -5, GETDATE()), DATEADD(day, -2, GETDATE()), 150.00, 'CheckedOut'),
        (2, 8, GETDATE(), DATEADD(day, 3, GETDATE()), 240.00, 'CheckedIn');
END
GO

-- Insert Payments
IF NOT EXISTS (SELECT * FROM [dbo].[Payments])
BEGIN
    INSERT INTO [dbo].[Payments] ([ReservationID], [PaymentDate], [Amount], [PaymentMethod])
    VALUES 
        (1, DATEADD(day, -5, GETDATE()), 150.00, 'Card'),
        (2, GETDATE(), 240.00, 'Cash');
END
GO

PRINT 'Database HotelManagementDB created successfully with sample data!';
GO
